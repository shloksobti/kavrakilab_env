# This script is used by the roscore systemd service unit
mkdir -p /var/log/ros/
chown ros:ros /var/log/ros/
